export default function Version() {
    return (
        <div className="bg-slate-800 h-6 w-16 rounded-xl text-center">
            v1.0.0
        </div> 
    )
}