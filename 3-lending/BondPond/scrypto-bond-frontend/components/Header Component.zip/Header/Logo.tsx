import Image from 'next/image'


export default function Logo() {
    return <>
        <a href="/" className='pl-10 pr-4'>
            <Image
                src="/media/logo_white.png"
                width={100}
                height={41.5}
                className="w-12 h-12 mr-4"
                alt="LearnGraph"
            />
        </a>
    </>
}